import React, { useState } from "react";

function CheckoutForm() {
  const [formData, setFormData] = useState({
    name: "",
    cardNumber: "",
    expiryDate: "",
    cvv: "",
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = "Name on card is required";
    if (!formData.cardNumber.match(/^\d{16}$/))
      newErrors.cardNumber = "Card number must be 16 digits";
    if (!formData.expiryDate.match(/^(0[1-9]|1[0-2])\/\d{2}$/))
      newErrors.expiryDate = "Expiry date must be in MM/YY format";
    if (!formData.cvv.match(/^\d{3}$/))
      newErrors.cvv = "CVV must be 3 digits";

    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validateForm();

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
    } else {
      alert("Payment submitted successfully!");
      setFormData({ name: "", cardNumber: "", expiryDate: "", cvv: "" });
      setErrors({});
    }
  };

  const handleClear = () => {
    setFormData({ name: "", cardNumber: "", expiryDate: "", cvv: "" });
    setErrors({});
  };

  return (
    <div
      style={{
        maxWidth: "400px",
        margin: "50px auto",
        padding: "20px",
        background: "#fff",
        borderRadius: "10px",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <h1
        style={{
          textAlign: "center",
          fontWeight: "bold",
          color: "#333",
          marginBottom: "20px",
        }}
      >
        Checkout
      </h1>
      <form onSubmit={handleSubmit}>
        {/* Name on Card */}
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "8px", fontWeight: "bold", color: "#555" }}>
            Name on Card:
          </label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            style={{
              width: "100%",
              padding: "10px",
              border: "1px solid #ddd",
              borderRadius: "5px",
              fontSize: "14px",
              boxSizing: "border-box", 
            }}
          />
          {errors.name && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "5px" }}>{errors.name}</p>
          )}
        </div>

        {/* Card Number */}
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "8px", fontWeight: "bold", color: "#555" }}>
            Card Number:
          </label>
          <input
            type="text"
            name="cardNumber"
            value={formData.cardNumber}
            onChange={handleChange}
            maxLength="16"
            style={{
              width: "100%",
              padding: "10px",
              border: "1px solid #ddd",
              borderRadius: "5px",
              fontSize: "14px",
              boxSizing: "border-box", 
            }}
          />
          {errors.cardNumber && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "5px" }}>{errors.cardNumber}</p>
          )}
        </div>

        {/* Expiry Date */}
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "8px", fontWeight: "bold", color: "#555" }}>
            Expiry Date (MM/YY):
          </label>
          <input
            type="text"
            name="expiryDate"
            value={formData.expiryDate}
            onChange={handleChange}
            placeholder="MM/YY"
            style={{
              width: "100%",
              padding: "10px",
              border: "1px solid #ddd",
              borderRadius: "5px",
              fontSize: "14px",
              boxSizing: "border-box", 
            }}
          />
          {errors.expiryDate && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "5px" }}>{errors.expiryDate}</p>
          )}
        </div>

        {/* CVV */}
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "8px", fontWeight: "bold", color: "#555" }}>
            CVV:
          </label>
          <input
            type="text"
            name="cvv"
            value={formData.cvv}
            onChange={handleChange}
            maxLength="3"
            style={{
              width: "100%",
              padding: "10px",
              border: "1px solid #ddd",
              borderRadius: "5px",
              fontSize: "14px",
              boxSizing: "border-box", 
            }}
          />
          {errors.cvv && (
            <p style={{ color: "red", fontSize: "12px", marginTop: "5px" }}>{errors.cvv}</p>
          )}
        </div>

        {/* Submit and Clear Buttons */}
        <div style={{ display: "flex", justifyContent: "space-between", gap: "10px" }}>
          <button
            type="submit"
            style={{
              flex: "1",
              padding: "10px",
              backgroundColor: "#007BFF",
              color: "white",
              border: "none",
              borderRadius: "5px",
              fontSize: "16px",
              fontWeight: "bold",
              cursor: "pointer",
            }}
          >
            Submit Payment
          </button>
          <button
            type="button"
            onClick={handleClear}
            style={{
              flex: "1",
              padding: "10px",
              backgroundColor: "#f44336",
              color: "white",
              border: "none",
              borderRadius: "5px",
              fontSize: "16px",
              fontWeight: "bold",
              cursor: "pointer",
            }}
          >
            Clear
          </button>
        </div>
      </form>
    </div>
  );
}

export default CheckoutForm;
