import React from "react";
import CheckoutForm from "./CheckoutForm";

function App() {
  return (
    <div>
      <CheckoutForm />
    </div>
  );
}

export default App;


