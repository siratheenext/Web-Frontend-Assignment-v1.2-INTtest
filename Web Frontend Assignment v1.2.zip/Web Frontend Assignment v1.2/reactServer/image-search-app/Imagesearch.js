import React, { useState } from "react";

function ImageSearch() {
  const [query, setQuery] = useState(""); 
  const [images, setImages] = useState([]); 
  const [page, setPage] = useState(1); 
  const [modalImage, setModalImage] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");

  const accessKey = process.env.REACT_APP_UNSPLASH_ACCESS_KEY;

  const searchImages = async () => {
    if (!query) {
      alert("Please enter a keyword");
      return;
    }

    try {
      const response = await fetch(
        `https://api.unsplash.com/search/photos?query=${query}&page=1&per_page=8&client_id=${accessKey}`
      );
      const data = await response.json();
      if (data.results.length === 0) {
        setErrorMessage(`No images found from this keyword "${query}"`);
      } else {
        setImages(data.results);
        setErrorMessage("");
      }
      setPage(1);
    } catch (error) {
      console.error("Error fetching images:", error);
      alert("An error occurred while fetching images.");
    }
  };

  const loadMoreImages = async () => {
    const nextPage = page + 1;
    try {
      const response = await fetch(
        `https://api.unsplash.com/search/photos?query=${query}&page=${nextPage}&per_page=8&client_id=${accessKey}`
      );
      const data = await response.json();
      setImages([...images, ...data.results]);
      setPage(nextPage);
    } catch (error) {
      console.error("Error loading more images:", error);
      alert("An error occurred while loading more images.");
    }
  };

  const openModal = (image) => {
    setModalImage(image);
  };

  const closeModal = () => {
    setModalImage(null);
  };

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1>Image Search App</h1>
      <input
        type="text"
        placeholder="Search for images"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            searchImages();
          }
        }}
        style={{
          width: "300px",
          padding: "10px",
          marginBottom: "20px",
          borderRadius: "5px",
          border: "1px solid #ddd",
          textAlign: "center",
        }}
      />
      {errorMessage && (
        <p style={{ color: "red", marginTop: "20px" }}>{errorMessage}</p>
      )}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
          gap: "10px",
          marginTop: "20px",
          padding: "0 20px",
        }}
      >
        {images.map((image) => (
          <img
            key={image.id}
            src={image.urls.thumb}
            alt={image.alt_description}
            onClick={() => openModal(image)}
            style={{
              width: "100%",
              borderRadius: "5px",
              cursor: "pointer",
              transition: "transform 0.2s",
            }}
            onMouseOver={(e) => (e.target.style.transform = "scale(1.05)")}
            onMouseOut={(e) => (e.target.style.transform = "scale(1)")}
          />
        ))}
      </div>

      {images.length > 0 && (
        <button
          onClick={loadMoreImages}
          style={{
            marginTop: "20px",
            padding: "10px 20px",
            backgroundColor: "#007BFF",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          Load More
        </button>
      )}

      {modalImage && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0, 0, 0, 0.8)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 1000,
          }}
          onClick={closeModal} 
        >
          <div
            style={{
              position: "relative",
              maxWidth: "90%",
              maxHeight: "90%",
            }}
            onClick={(e) => e.stopPropagation()} 
          >
            <img
              src={modalImage.urls.full}
              alt={modalImage.alt_description}
              style={{
                width: "100%",
                height: "auto",
                borderRadius: "10px",
              }}
            />
            <button
              onClick={closeModal}
              style={{
                position: "absolute",
                top: "10px",
                right: "10px",
                background: "red",
                color: "white",
                border: "none",
                padding: "10px 15px",
                borderRadius: "5px",
                cursor: "pointer",
                fontSize: "14px",
                fontWeight: "bold",
              }}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default ImageSearch;
